package com.rocky.laporan;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    // Nama printer bisa muncul beda tipis di HP: RPPO2N-F557 atau RPP02N-F557.
    // Karena itu aplikasi sekarang tidak bergantung 100% ke satu tulisan nama saja.
    private static final String PRINTER_NAME = "RPPO2N-F557";
    private static final String[] PRINTER_ALIASES = {
            "RPPO2N-F557", "RPP02N-F557", "RPPO2N", "RPP02N", "F557"
    };
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQ_BLUETOOTH = 557;
    private static final String PREFS = "rocky_printer_prefs";
    private static final String PREF_PRINTER_ADDRESS = "printer_address";
    private WebView webView;
    private long lastBackPressAt = 0L;
    private float touchStartX = 0f;
    private float touchStartY = 0f;
    private boolean edgeSwipeStarted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();
        setupWebView();
        requestBluetoothPermissionIfNeeded();
    }

    private void configureSystemBars() {
        // SAFE FULLSCREEN: pakai flag Android lama yang stabil di banyak HP.
        // Versi 1.2 memakai WindowInsetsController + decorFitsSystemWindows(false),
        // di sebagian device/WebView bisa force close. Versi ini tetap fullscreen,
        // tapi tidak memakai kombinasi yang rawan crash itu.
        Window window = getWindow();
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        window.getDecorView().setSystemUiVisibility(flags);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setNavigationBarColor(Color.WHITE);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#F3F6F8"));
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);
        applySafeAreaInsets(root);
        setupSwipeBackGesture();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        // HTML berada di android_asset, tetapi script Firebase/Supabase/CDN memakai HTTPS.
        // Ini membantu WebView menjalankan request internet dari file lokal aplikasi.
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PrinterBridge(), "RockyPrinter");
        webView.loadUrl("file:///android_asset/Laporan.html");
    }

    private void applySafeAreaInsets(FrameLayout root) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                // Status bar disembunyikan, jadi top padding 0.
                // Bottom tetap dipakai supaya menu bawah tidak ketabrak navigation bar.
                int bottom = insets.getSystemWindowInsetBottom();
                view.setPadding(0, 0, 0, bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
    }

    private void setupSwipeBackGesture() {
        if (webView == null) return;
        final float density = getResources().getDisplayMetrics().density;
        final float edgeSize = 34f * density;
        final float minSwipe = 85f * density;
        final float maxVertical = 115f * density;

        webView.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    touchStartX = event.getX();
                    touchStartY = event.getY();
                    int width = v.getWidth();
                    edgeSwipeStarted = touchStartX <= edgeSize || touchStartX >= (width - edgeSize);
                    break;
                case MotionEvent.ACTION_UP:
                    if (edgeSwipeStarted) {
                        float dx = event.getX() - touchStartX;
                        float dy = event.getY() - touchStartY;
                        if (Math.abs(dx) >= minSwipe && Math.abs(dy) <= maxVertical) {
                            handleBackNavigation();
                            edgeSwipeStarted = false;
                            return true;
                        }
                    }
                    edgeSwipeStarted = false;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    edgeSwipeStarted = false;
                    break;
            }
            return false;
        });
    }

    private boolean hasBluetoothConnectPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothConnectPermission()) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
            }, REQ_BLUETOOTH);
        }
    }

    private void toast(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    public class PrinterBridge {
        @JavascriptInterface
        public void printReceipt(final String receiptText) {
            if (!hasBluetoothConnectPermission()) {
                requestBluetoothPermissionIfNeeded();
                toast("Izinkan Nearby devices / Bluetooth dulu, lalu tekan Cetak Struk lagi.");
                return;
            }
            new Thread(() -> printToBluetooth(receiptText == null ? "" : receiptText)).start();
        }

        @JavascriptInterface
        public void showPrinterPicker() {
            if (!hasBluetoothConnectPermission()) {
                requestBluetoothPermissionIfNeeded();
                toast("Izinkan Nearby devices / Bluetooth dulu, lalu tekan Pilih Printer lagi.");
                return;
            }
            showPrinterPickerDialog(false);
        }
    }

    @SuppressLint("MissingPermission")
    private void printToBluetooth(String receiptText) {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            toast("Bluetooth tidak tersedia di HP ini.");
            return;
        }
        if (!adapter.isEnabled()) {
            toast("Bluetooth masih mati. Nyalakan Bluetooth dan pair printer " + PRINTER_NAME + ".");
            return;
        }

        BluetoothDevice printer = findSavedPrinter(adapter);
        if (printer == null) printer = findBondedPrinter(adapter);
        if (printer == null) {
            showPrinterPickerDialog(true);
            return;
        }

        BluetoothSocket socket = null;
        String printerName = safeDeviceName(printer);
        try {
            adapter.cancelDiscovery();
            socket = createSocket(printer);
            socket.connect();
            OutputStream out = socket.getOutputStream();

            // ESC/POS umum untuk printer thermal 58mm/80mm.
            out.write(new byte[]{0x1B, 0x40});          // initialize
            out.write(new byte[]{0x1B, 0x61, 0x01});    // center
            out.write("ROCKY\n".getBytes(Charset.forName("GBK")));
            out.write(new byte[]{0x1B, 0x61, 0x00});    // left
            out.write(receiptText.getBytes(Charset.forName("GBK")));
            out.write("\n\n\n".getBytes(Charset.forName("GBK")));
            out.flush();
            savePrinterAddress(printer.getAddress());
            toast("Struk berhasil dikirim ke " + printerName + ".");
        } catch (Exception e) {
            toast("Gagal cetak ke " + printerName + ": " + e.getMessage());
        } finally {
            if (socket != null) {
                try { socket.close(); } catch (Exception ignored) {}
            }
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void savePrinterAddress(String address) {
        if (address == null || address.trim().isEmpty()) return;
        prefs().edit().putString(PREF_PRINTER_ADDRESS, address).apply();
    }

    @SuppressLint("MissingPermission")
    private BluetoothDevice findSavedPrinter(BluetoothAdapter adapter) {
        String address = prefs().getString(PREF_PRINTER_ADDRESS, "");
        if (address == null || address.trim().isEmpty()) return null;
        Set<BluetoothDevice> devices = adapter.getBondedDevices();
        if (devices == null) return null;
        for (BluetoothDevice device : devices) {
            if (address.equalsIgnoreCase(device.getAddress())) return device;
        }
        return null;
    }

    @SuppressLint("MissingPermission")
    private BluetoothDevice findBondedPrinter(BluetoothAdapter adapter) {
        Set<BluetoothDevice> devices = adapter.getBondedDevices();
        if (devices == null || devices.isEmpty()) return null;

        // 1) Cocokkan target/alias dulu.
        for (BluetoothDevice device : devices) {
            String name = safeDeviceName(device);
            if (isTargetPrinterName(name)) return device;
        }

        // 2) Kalau cuma ada 1 device paired, pakai itu. Ini sering terjadi di HP kasir.
        if (devices.size() == 1) return devices.iterator().next();

        // 3) Cari nama yang kemungkinan besar printer thermal/POS.
        BluetoothDevice best = null;
        int bestScore = 0;
        for (BluetoothDevice device : devices) {
            String name = safeDeviceName(device);
            int score = printerNameScore(name);
            if (score > bestScore) {
                bestScore = score;
                best = device;
            }
        }
        return bestScore >= 2 ? best : null;
    }

    private String safeDeviceName(BluetoothDevice device) {
        if (device == null) return "Printer";
        try {
            String name = device.getName();
            if (name != null && !name.trim().isEmpty()) return name.trim();
        } catch (Exception ignored) {}
        try {
            String address = device.getAddress();
            if (address != null) return address;
        } catch (Exception ignored) {}
        return "Printer";
    }

    private String normalizeName(String s) {
        String text = String.valueOf(s == null ? "" : s).toUpperCase();
        // Huruf O dan angka 0 sering ketukar pada nama RPP02N/RPPO2N.
        text = text.replace('O', '0');
        return text.replaceAll("[^A-Z0-9]", "");
    }

    private boolean isTargetPrinterName(String name) {
        String n = normalizeName(name);
        for (String alias : PRINTER_ALIASES) {
            String a = normalizeName(alias);
            if (!a.isEmpty() && (n.equals(a) || n.contains(a) || a.contains(n))) return true;
        }
        return false;
    }

    private int printerNameScore(String name) {
        String n = normalizeName(name);
        int score = 0;
        if (n.contains("F557")) score += 5;
        if (n.contains("RPP")) score += 4;
        if (n.contains("POS")) score += 3;
        if (n.contains("PRINT") || n.contains("PRINTER")) score += 3;
        if (n.contains("THERMAL")) score += 3;
        if (n.contains("SPP")) score += 2;
        if (n.contains("BT")) score += 1;
        if (n.contains("58") || n.contains("80")) score += 1;
        return score;
    }

    @SuppressLint("MissingPermission")
    private List<BluetoothDevice> bondedDeviceList() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        List<BluetoothDevice> list = new ArrayList<>();
        if (adapter == null || !adapter.isEnabled()) return list;
        Set<BluetoothDevice> devices = adapter.getBondedDevices();
        if (devices != null) list.addAll(devices);
        return list;
    }

    private void showPrinterPickerDialog(boolean printFailedBecauseNotFound) {
        runOnUiThread(() -> {
            if (!hasBluetoothConnectPermission()) {
                requestBluetoothPermissionIfNeeded();
                toast("Izinkan Nearby devices / Bluetooth dulu.");
                return;
            }
            List<BluetoothDevice> devices = bondedDeviceList();
            if (devices.isEmpty()) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Printer belum terbaca")
                        .setMessage("Aplikasi belum menemukan perangkat Bluetooth yang sudah dipairing.\n\nBuka Pengaturan Bluetooth HP, hapus pairing lama kalau perlu, lalu pairing ulang printer RPPO2N-F557/RPP02N-F557. Setelah status Paired/Connected, kembali ke aplikasi dan tekan Cetak Struk lagi.")
                        .setPositiveButton("OK", null)
                        .show();
                return;
            }

            String[] labels = new String[devices.size()];
            for (int i = 0; i < devices.size(); i++) {
                BluetoothDevice d = devices.get(i);
                labels[i] = safeDeviceName(d) + "\n" + d.getAddress();
            }
            String title = printFailedBecauseNotFound ? "Pilih printer dulu" : "Pilih printer Bluetooth";
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle(title)
                    .setItems(labels, (dialog, which) -> {
                        BluetoothDevice selected = devices.get(which);
                        savePrinterAddress(selected.getAddress());
                        toast("Printer disimpan: " + safeDeviceName(selected) + ". Tekan Cetak Struk lagi.");
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        });
    }

    @SuppressLint("MissingPermission")
    private BluetoothSocket createSocket(BluetoothDevice device) throws Exception {
        try {
            return device.createRfcommSocketToServiceRecord(SPP_UUID);
        } catch (Exception first) {
            try {
                return device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
            } catch (Exception second) {
                Method method = device.getClass().getMethod("createRfcommSocket", int.class);
                return (BluetoothSocket) method.invoke(device, 1);
            }
        }
    }

    private void handleBackNavigation() {
        if (webView == null) {
            finish();
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{return !!(window.appBack && window.appBack());}catch(e){return false;}})();",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView.canGoBack()) {
                        webView.goBack();
                        return;
                    }
                    long now = System.currentTimeMillis();
                    if (now - lastBackPressAt < 2000L) {
                        moveTaskToBack(true);
                    } else {
                        lastBackPressAt = now;
                        toast("Geser/tekan kembali sekali lagi untuk keluar.");
                    }
                }
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            configureSystemBars();
        }
    }

    @Override
    public void onBackPressed() {
        handleBackNavigation();
    }
}
