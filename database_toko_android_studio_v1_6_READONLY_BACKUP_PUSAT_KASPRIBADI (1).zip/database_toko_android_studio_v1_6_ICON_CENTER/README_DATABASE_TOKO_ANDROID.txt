DATABASE TOKO - Android Studio Project

- Nama aplikasi: DATABASE TOKO
- WebView offline dari Laporan.html
- Internet permission aktif
- Bluetooth printer aktif untuk cetak struk
- Printer default: RPPO2N-F557 / RPP02N-F557 / F557
- Fullscreen status bar aktif
- Swipe/back aman: kembali ke halaman sebelumnya dulu
- Icon aplikasi auto-generate saat Build APK

GANTI ICON:
1. Buka folder GANTI_ICON_APLIKASI
2. Ganti file ikon_aplikasi.png
3. Ganti warna background di warna_background_icon.txt
4. Build APK lagi

Catatan:
Jika warna background icon tidak berubah, berarti gambar ikon_aplikasi.png sudah punya background penuh/opaque. Pakai PNG transparan agar warna background dari warna_background_icon.txt terlihat.


UPDATE v1.6 ICON CENTER:
- Logo icon otomatis diperkecil dan ditaruh pas di tengah.
- Atur besar logo di GANTI_ICON_APLIKASI/ukuran_logo_icon.txt. Default 70.
- Jika masih kebesaran, ganti ke 60 atau 65 lalu build ulang.
