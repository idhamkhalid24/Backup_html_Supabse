DATABASE TOKO - Android Studio Project
=====================================

Update versi 1.1:
- Nama aplikasi diganti menjadi DATABASE TOKO.
- Tombol/card Pilih Printer di halaman Keuangan dihapus.
- Tombol Cetak Struk tetap aktif dan tetap memakai printer Bluetooth RPPO2N-F557/RPP02N-F557.
- Jika printer belum tersimpan/terbaca, aplikasi masih bisa membuka pilihan printer otomatis dari daftar perangkat Bluetooth yang sudah paired.
- Gesture kembali diperbaiki: swipe/back akan kembali ke halaman/tab sebelumnya dulu, tidak langsung keluar aplikasi.
- Saat berada di Home, perlu back dua kali untuk keluar.
- Safe area/status bar diperbaiki supaya tampilan WebView tidak tembus ke status bar dan navigation bar HP.

Cara buka:
1. Extract ZIP ini.
2. Buka Android Studio > Open > pilih folder project ini.
3. Tunggu Gradle Sync.
4. Build APK / Run ke HP.
5. Install sebagai update dari versi sebelumnya supaya setting printer tetap tersimpan.

Catatan printer:
- Pastikan printer sudah paired di pengaturan Bluetooth HP.
- Nama printer yang didukung: RPPO2N-F557, RPP02N-F557, RPPO2N, RPP02N, atau F557.
- Cetak struk ada di halaman Keuangan > card Laporan Keuangan Bulanan > Cetak Struk.

Ganti icon aplikasi:
- Ganti gambar di folder GANTI_ICON_APLIKASI/ikon_aplikasi.png.
- Jalankan tools/generate_icons.py untuk generate semua ukuran mipmap Android.


UPDATE v1.6 ICON CENTER:
- Logo icon otomatis diperkecil dan ditaruh pas di tengah.
- Atur besar logo di GANTI_ICON_APLIKASI/ukuran_logo_icon.txt. Default 70.
- Jika masih kebesaran, ganti ke 60 atau 65 lalu build ulang.
