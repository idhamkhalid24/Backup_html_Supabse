from pathlib import Path
from PIL import Image, ImageColor, ImageChops

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "GANTI_ICON_APLIKASI" / "ikon_aplikasi.png"
BG_FILE = ROOT / "GANTI_ICON_APLIKASI" / "warna_background_icon.txt"
SCALE_FILE = ROOT / "GANTI_ICON_APLIKASI" / "ukuran_logo_icon.txt"
OUT = ROOT / "app" / "src" / "main" / "res"
SIZES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

if not SOURCE.exists():
    raise SystemExit(f"File icon tidak ditemukan: {SOURCE}")

bg_text = "#00A878"
if BG_FILE.exists():
    bg_text = BG_FILE.read_text(encoding="utf-8").strip()
try:
    bg_color = ImageColor.getcolor(bg_text, "RGBA")
except Exception as e:
    raise SystemExit(f"Format warna background salah di {BG_FILE}. Contoh: #00A878") from e

scale_percent = 70
if SCALE_FILE.exists():
    raw_scale = SCALE_FILE.read_text(encoding="utf-8").strip().replace('%', '')
    try:
        scale_percent = int(raw_scale)
    except Exception as e:
        raise SystemExit(f"Format ukuran logo salah di {SCALE_FILE}. Isi angka saja, contoh: 70") from e
scale_percent = max(45, min(90, scale_percent))

img = Image.open(SOURCE).convert("RGBA")

# Ambil batas objek yang terlihat dari alpha channel supaya logo benar-benar di tengah,
# bukan mengikuti canvas gambar yang mungkin punya padding tidak rata.
alpha = img.getchannel("A")
bbox = alpha.getbbox()
if bbox:
    img = img.crop(bbox)
else:
    # Kalau gambar tidak punya alpha/semuanya transparan, pakai crop kotak tengah sebagai fallback.
    side = min(img.size)
    left = (img.width - side) // 2
    top = (img.height - side) // 2
    img = img.crop((left, top, left + side, top + side))

for folder, size in SIZES.items():
    target_dir = OUT / folder
    target_dir.mkdir(parents=True, exist_ok=True)
    canvas = Image.new("RGBA", (size, size), bg_color)

    max_logo = int(size * scale_percent / 100)
    ratio = min(max_logo / img.width, max_logo / img.height)
    new_w = max(1, int(img.width * ratio))
    new_h = max(1, int(img.height * ratio))
    logo = img.resize((new_w, new_h), Image.LANCZOS)

    x = (size - new_w) // 2
    y = (size - new_h) // 2
    canvas.alpha_composite(logo, (x, y))

    canvas.save(target_dir / "ic_launcher.png")
    canvas.save(target_dir / "ic_launcher_round.png")
    print(f"OK {folder}: {size}x{size}, logo {scale_percent}%, center, background {bg_text}")

print("Selesai. Sync ulang project di Android Studio lalu build APK.")
