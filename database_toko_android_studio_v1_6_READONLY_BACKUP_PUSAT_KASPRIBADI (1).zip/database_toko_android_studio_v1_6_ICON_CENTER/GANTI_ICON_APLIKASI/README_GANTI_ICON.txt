CARA GANTI ICON APLIKASI DATABASE TOKO

1. Ganti gambar logo di file:
   GANTI_ICON_APLIKASI/ikon_aplikasi.png

2. Ganti warna background icon di file:
   GANTI_ICON_APLIKASI/warna_background_icon.txt

   Contoh isi:
   #00A878
   #111827
   #FFFFFF

3. Atur besar/kecil logo di tengah icon di file:
   GANTI_ICON_APLIKASI/ukuran_logo_icon.txt

   Isi angka saja. Default: 70
   Kalau logo masih terlalu besar, pakai 60 atau 65.
   Kalau logo terlalu kecil, pakai 75 atau 80.

4. Build APK di Android Studio.
   Icon otomatis dibuat ulang ke semua ukuran Android saat build.

CATATAN:
- Paling bagus pakai PNG transparan/logo tanpa background.
- Script otomatis mengambil bagian logo yang terlihat lalu menaruhnya tepat di tengah.
- Kalau HP masih menampilkan icon lama, uninstall aplikasi DATABASE TOKO dulu lalu install APK terbaru karena launcher HP kadang menyimpan cache icon.
