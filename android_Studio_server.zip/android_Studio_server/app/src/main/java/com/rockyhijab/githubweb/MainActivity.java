package com.rockyhijab.githubweb;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQUEST_FILE_CHOOSER = 4211;
    private static final int REQUEST_WRITE_STORAGE = 909;
    private static final int REQUEST_BLUETOOTH_CONNECT = 910;
    private static final String FALLBACK_ASSET = "index.html";
    private static final String FALLBACK_BASE_URL = "https://local.rockyhijab.app/";
    private static final String BACKUP_FOLDER = "RockyBackup";
    private static final long EXIT_CONFIRM_MS = 1800L;

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String configuredHtmlUrl;
    private String configuredHtmlHost;
    private boolean fallbackLoaded;
    private long lastBackPressAt;
    private OnBackInvokedCallback backInvokedCallback;
    private boolean jsBackCheckInProgress;
    private String pendingBluetoothPrintText;
    private final Map<String, PendingDownload> pendingDownloads = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configuredHtmlUrl = getString(R.string.github_html_url).trim();
        configuredHtmlHost = hostOf(configuredHtmlUrl);
        setupUi();
        configureWebView();
        registerBackHandler();
        loadConfiguredPage();
    }

    private void setupUi() {
        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);
        int systemUi = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) systemUi |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) systemUi |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        window.getDecorView().setSystemUiVisibility(systemUi);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                view.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            }
        });

        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(3),
                Gravity.TOP
        );
        root.addView(progressBar, progressParams);

        setContentView(root);
        root.requestApplyInsets();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        webView.addJavascriptInterface(new StorageBridge(), "AndroidStorage");
        AndroidPrinterBridge printerBridge = new AndroidPrinterBridge();
        webView.addJavascriptInterface(printerBridge, "Android");
        webView.addJavascriptInterface(printerBridge, "AndroidPrinter");
        webView.addJavascriptInterface(printerBridge, "AndroidPrinterBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = filePathCallback;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                            "application/json",
                            "text/plain",
                            "application/vnd.ms-excel",
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    });
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }

                try {
                    startActivityForResult(intent, REQUEST_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Pemilih file tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAndroidStorageHelper();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && request != null && request.isForMainFrame()) {
                    loadFallbackOnce();
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                super.onReceivedHttpError(view, request, response);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                        && request != null && request.isForMainFrame()
                        && response != null && response.getStatusCode() >= 400) {
                    loadFallbackOnce();
                }
            }
        });
    }

    private void loadConfiguredPage() {
        fallbackLoaded = false;
        if (isUsableRemoteUrl(configuredHtmlUrl)) {
            webView.loadUrl(withCacheBust(configuredHtmlUrl));
        } else {
            loadFallbackAsset();
        }
    }

    private void loadFallbackOnce() {
        if (!fallbackLoaded) loadFallbackAsset();
    }

    private void loadFallbackAsset() {
        fallbackLoaded = true;
        try {
            String html = readAsset(FALLBACK_ASSET);
            webView.loadDataWithBaseURL(FALLBACK_BASE_URL, html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "GitHub tidak bisa dibuka dan HTML cadangan gagal dimuat.", Toast.LENGTH_LONG).show();
        }
    }

    private void injectAndroidStorageHelper() {
        try {
            String js = readAsset("android-storage-bridge.js");
            webView.evaluateJavascript(js, null);
        } catch (Exception e) {
            Toast.makeText(this, "Bridge backup Android gagal dimuat.", Toast.LENGTH_SHORT).show();
        }
    }

    private String readAsset(String assetName) throws Exception {
        InputStream stream = getAssets().open(assetName);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) builder.append(line).append('\n');
        reader.close();
        return builder.toString();
    }

    private boolean isCurrentPageTrusted() {
        String currentHost = hostOf(webView == null ? null : webView.getUrl());
        if ("local.rockyhijab.app".equalsIgnoreCase(currentHost)) return true;
        return configuredHtmlHost != null && configuredHtmlHost.equalsIgnoreCase(currentHost);
    }

    private boolean isUsableRemoteUrl(String url) {
        if (url == null || url.trim().isEmpty()) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        return uri.getHost() != null && ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
    }

    private String withCacheBust(String url) {
        String separator = url.contains("?") ? "&" : "?";
        return url + separator + "apk_v=" + System.currentTimeMillis();
    }

    private String hostOf(String url) {
        try {
            return url == null ? null : Uri.parse(url).getHost();
        } catch (Exception ignored) {
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FILE_CHOOSER || fileChooserCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[] { data.getData() };
            }
        }
        fileChooserCallback.onReceiveValue(results);
        fileChooserCallback = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BLUETOOTH_CONNECT) {
            boolean canPrint = hasBluetoothConnectPermissionForPrint();
            final String text = pendingBluetoothPrintText;
            pendingBluetoothPrintText = null;
            if (canPrint && text != null && !text.trim().isEmpty()) {
                Toast.makeText(this, "Izin Bluetooth aktif, mencetak ulang struk...", Toast.LENGTH_SHORT).show();
                new Thread(new Runnable() {
                    @Override public void run() { new AndroidPrinterBridge().printReceipt(text); }
                }).start();
            } else if (!canPrint) {
                Toast.makeText(this, "Izin Nearby devices/Bluetooth wajib untuk cetak struk.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && !jsBackCheckInProgress) {
            jsBackCheckInProgress = true;
            webView.evaluateJavascript(
                    "(function(){try{return !!(window.__rockyNativeBack && window.__rockyNativeBack());}catch(e){return false;}})();",
                    value -> {
                        jsBackCheckInProgress = false;
                        if (!"true".equals(String.valueOf(value))) {
                            runOnUiThread(new Runnable() {
                                @Override public void run() { handleNativeBackFallback(); }
                            });
                        }
                    }
            );
            return;
        }
        handleNativeBackFallback();
    }

    private void handleNativeBackFallback() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPressAt <= EXIT_CONFIRM_MS) {
            finish();
        } else {
            lastBackPressAt = now;
            Toast.makeText(this, "Tekan kembali sekali lagi untuk keluar.", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerBackHandler() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return;
        backInvokedCallback = new OnBackInvokedCallback() {
            @Override public void onBackInvoked() { onBackPressed(); }
        };
        getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                backInvokedCallback
        );
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backInvokedCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backInvokedCallback);
        }
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private class StorageBridge {
        @JavascriptInterface
        public boolean saveFileToDownloads(String filename, String mimeType, String base64Data) {
            // Jangan blokir berdasarkan host, karena GitHub Pages/redirect kadang membuat host WebView berbeda.
            if (!ensureLegacyWritePermissionIfNeeded()) return false;
            try {
                String safeName = sanitizeDownloadFilename(filename);
                String safeMime = sanitizeMimeType(mimeType);
                byte[] data = Base64.decode(String.valueOf(base64Data), Base64.DEFAULT);
                writeBytesToDownloads(safeName, safeMime, data);
                showSavedToast(safeName);
                return true;
            } catch (Exception e) {
                showFailedToast(e);
                return false;
            }
        }

        @JavascriptInterface
        public String beginSaveToDownloads(String filename, String mimeType) {
            // Jangan blokir berdasarkan host, supaya halaman GitHub tetap bisa menyimpan backup.
            if (!ensureLegacyWritePermissionIfNeeded()) return "";
            try {
                String sessionId = UUID.randomUUID().toString();
                File temp = File.createTempFile("rocky-backup-", ".bin", getCacheDir());
                PendingDownload pending = new PendingDownload(
                        sanitizeDownloadFilename(filename),
                        sanitizeMimeType(mimeType),
                        temp,
                        new FileOutputStream(temp)
                );
                synchronized (pendingDownloads) { pendingDownloads.put(sessionId, pending); }
                return sessionId;
            } catch (Exception e) {
                showFailedToast(e);
                return "";
            }
        }

        @JavascriptInterface
        public boolean appendSaveChunk(String sessionId, String base64Chunk) {
            PendingDownload pending = getPendingDownload(sessionId);
            if (pending == null) return false;
            try {
                pending.output.write(Base64.decode(String.valueOf(base64Chunk), Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                cancelPendingDownload(sessionId);
                showFailedToast(e);
                return false;
            }
        }

        @JavascriptInterface
        public boolean finishSaveToDownloads(String sessionId) {
            PendingDownload pending = removePendingDownload(sessionId);
            if (pending == null) return false;
            try {
                pending.output.flush();
                pending.output.close();
                writeFileToDownloads(pending.filename, pending.mimeType, pending.tempFile);
                //noinspection ResultOfMethodCallIgnored
                pending.tempFile.delete();
                showSavedToast(pending.filename);
                return true;
            } catch (Exception e) {
                try { pending.output.close(); } catch (Exception ignored) {}
                try { pending.tempFile.delete(); } catch (Exception ignored) {}
                showFailedToast(e);
                return false;
            }
        }

        @JavascriptInterface
        public boolean cancelSaveToDownloads(String sessionId) {
            cancelPendingDownload(sessionId);
            return true;
        }
    }


    private class AndroidPrinterBridge {
        private final java.util.UUID SPP_UUID = java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

        @JavascriptInterface
        public boolean printReceipt(String receiptText) {
            final String textToPrint = String.valueOf(receiptText == null ? "" : receiptText);
            if (!ensureBluetoothPermissionIfNeeded(textToPrint)) return false;
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new IllegalStateException("Bluetooth tidak tersedia");
                if (!adapter.isEnabled()) throw new IllegalStateException("Bluetooth belum aktif");
                BluetoothDevice device = choosePrinterDevice(adapter.getBondedDevices());
                if (device == null) throw new IllegalStateException("Printer Bluetooth belum dipairing");
                BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                // Pada Android 12+, cancelDiscovery butuh BLUETOOTH_SCAN.
                // Kalau izin scan belum ada, jangan gagalkan cetak; langsung connect saja.
                try {
                    if (canCallBluetoothScanOperation()) adapter.cancelDiscovery();
                } catch (Exception ignored) {}
                socket.connect();
                OutputStream out = socket.getOutputStream();
                out.write(new byte[] { 0x1B, 0x40, 0x1B, 0x61, 0x00 });
                out.write(textToPrint.getBytes("UTF-8"));
                out.write(new byte[] { '\n', '\n', '\n', 0x1D, 0x56, 0x42, 0x00 });
                out.flush();
                try { out.close(); } catch (Exception ignored) {}
                try { socket.close(); } catch (Exception ignored) {}
                showPrinterToast("Struk dikirim ke " + safeDeviceName(device));
                return true;
            } catch (Exception e) {
                showPrinterToast("Gagal cetak struk: " + e.getMessage());
                return false;
            }
        }
    }

    private boolean ensureBluetoothPermissionIfNeeded(String receiptText) {
        if (!hasBluetoothConnectPermissionForPrint()) {
            pendingBluetoothPrintText = receiptText;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        requestPermissions(new String[] {
                                Manifest.permission.BLUETOOTH_CONNECT,
                                Manifest.permission.BLUETOOTH_SCAN
                        }, REQUEST_BLUETOOTH_CONNECT);
                        Toast.makeText(MainActivity.this, "Izinkan Nearby devices/Bluetooth. Setelah izin aktif, struk dicetak otomatis.", Toast.LENGTH_LONG).show();
                    }
                }
            });
            return false;
        }
        return true;
    }

    private boolean hasBluetoothConnectPermissionForPrint() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean canCallBluetoothScanOperation() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
    }

    private BluetoothDevice choosePrinterDevice(Set<BluetoothDevice> devices) {
        if (devices == null || devices.isEmpty()) return null;
        BluetoothDevice fallback = null;
        for (BluetoothDevice d : devices) {
            if (d == null) continue;
            if (fallback == null) fallback = d;
            String name = safeDeviceName(d).toLowerCase(Locale.US);
            if (name.contains("printer") || name.contains("pos") || name.contains("rpp") || name.contains("mtp") || name.contains("thermal") || name.contains("esc")) return d;
        }
        return fallback;
    }

    private String safeDeviceName(BluetoothDevice device) {
        try {
            String name = device == null ? null : device.getName();
            return (name == null || name.trim().isEmpty()) ? "Printer Bluetooth" : name.trim();
        } catch (Exception ignored) {
            return "Printer Bluetooth";
        }
    }

    private void showPrinterToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }


    private static class PendingDownload {
        final String filename;
        final String mimeType;
        final File tempFile;
        final FileOutputStream output;
        PendingDownload(String filename, String mimeType, File tempFile, FileOutputStream output) {
            this.filename = filename;
            this.mimeType = mimeType;
            this.tempFile = tempFile;
            this.output = output;
        }
    }

    private PendingDownload getPendingDownload(String sessionId) {
        if (sessionId == null || sessionId.isEmpty()) return null;
        synchronized (pendingDownloads) { return pendingDownloads.get(sessionId); }
    }

    private PendingDownload removePendingDownload(String sessionId) {
        if (sessionId == null || sessionId.isEmpty()) return null;
        synchronized (pendingDownloads) { return pendingDownloads.remove(sessionId); }
    }

    private void cancelPendingDownload(String sessionId) {
        PendingDownload pending = removePendingDownload(sessionId);
        if (pending == null) return;
        try { pending.output.close(); } catch (Exception ignored) {}
        try { pending.tempFile.delete(); } catch (Exception ignored) {}
    }

    private boolean ensureLegacyWritePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    requestPermissions(new String[] { Manifest.permission.WRITE_EXTERNAL_STORAGE }, REQUEST_WRITE_STORAGE);
                    Toast.makeText(MainActivity.this, "Izinkan penyimpanan dulu, lalu backup ulang.", Toast.LENGTH_LONG).show();
                }
            });
            return false;
        }
        return true;
    }

    private String sanitizeDownloadFilename(String filename) {
        String name = filename == null ? "rocky-backup.json" : filename.trim();
        if (name.isEmpty()) name = "rocky-backup.json";
        name = name.replaceAll("[\\\\/:*?\"<>|\r\n]+", "-");
        String lower = name.toLowerCase(Locale.US);
        if (!lower.endsWith(".json") && !lower.endsWith(".csv") && !lower.endsWith(".xlsx") && !lower.endsWith(".xls") && !lower.endsWith(".txt")) {
            name += ".json";
        }
        return name;
    }

    private String sanitizeMimeType(String mimeType) {
        if (mimeType == null || mimeType.trim().isEmpty()) return "application/octet-stream";
        return mimeType.split(";")[0].trim();
    }

    private void writeBytesToDownloads(String filename, String mimeType, byte[] data) throws Exception {
        // Sekarang hanya simpan 1 lokasi agar tidak dobel:
        // Download/RockyBackup/filename
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            writeBytesToMediaStore(filename, mimeType, data, Environment.DIRECTORY_DOWNLOADS + "/" + BACKUP_FOLDER);
            return;
        }
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File dir = new File(downloads, BACKUP_FOLDER);
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Folder Download/" + BACKUP_FOLDER + " tidak bisa dibuat");
        File subFile = uniqueFile(dir, filename);
        try (OutputStream out = new FileOutputStream(subFile)) { out.write(data); }
        scanDownloadedFile(subFile, mimeType);
    }

    private void writeFileToDownloads(String filename, String mimeType, File sourceFile) throws Exception {
        byte[] data;
        try (InputStream in = new FileInputStream(sourceFile)) {
            data = readAllBytesCompat(in);
        }
        writeBytesToDownloads(filename, mimeType, data);
    }

    private void writeBytesToMediaStore(String filename, String mimeType, byte[] data, String relativePath) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
        values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
        values.put(MediaStore.Downloads.RELATIVE_PATH, relativePath);
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("MediaStore gagal membuat file");
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("Output stream kosong");
            out.write(data);
        }
        values.clear();
        values.put(MediaStore.Downloads.IS_PENDING, 0);
        getContentResolver().update(uri, values, null, null);
    }

    private byte[] readAllBytesCompat(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        byte[] chunk = new byte[64 * 1024];
        int read;
        while ((read = in.read(chunk)) != -1) buffer.write(chunk, 0, read);
        return buffer.toByteArray();
    }

    private File uniqueFile(File dir, String filename) {
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, filename);
        if (!file.exists()) return file;
        int dot = filename.lastIndexOf('.');
        String base = dot > 0 ? filename.substring(0, dot) : filename;
        String ext = dot > 0 ? filename.substring(dot) : "";
        return new File(dir, base + "-" + System.currentTimeMillis() + ext);
    }

    private void scanDownloadedFile(File file, String mimeType) {
        try {
            MediaScannerConnection.scanFile(this, new String[] { file.getAbsolutePath() }, new String[] { sanitizeMimeType(mimeType) }, null);
        } catch (Exception ignored) {}
    }

    private void showSavedToast(final String filename) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this, "Backup tersimpan: Download/" + BACKUP_FOLDER + "/" + filename, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showFailedToast(final Exception e) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this, "Gagal menyimpan backup: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
