(function(){
  if (window.__rockyAndroidStorageHookV5_FORCE) return;
  window.__rockyAndroidStorageHookV5_FORCE = true;

  var blobStore = Object.create(null);
  var nativeCreateObjectURL = window.URL && window.URL.createObjectURL ? window.URL.createObjectURL.bind(window.URL) : null;
  var nativeRevokeObjectURL = window.URL && window.URL.revokeObjectURL ? window.URL.revokeObjectURL.bind(window.URL) : null;

  function bridge(){
    var list = [window.AndroidStorage, window.RockyStorage, window.RockyBridge, window.Android, window.NativeBridge];
    for (var i=0;i<list.length;i++) {
      if (list[i] && (typeof list[i].saveFileToDownloads === 'function' || typeof list[i].beginSaveToDownloads === 'function')) return list[i];
    }
    return null;
  }

  function toast(msg, error){
    try {
      if (typeof window.showToast === 'function') window.showToast(msg, !!error);
      else console.log(msg);
    } catch(e) { console.log(msg); }
  }

  function guessMime(filename, fallback){
    var lower = String(filename || '').toLowerCase();
    if (lower.endsWith('.json')) return 'application/json';
    if (lower.endsWith('.xlsx')) return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    if (lower.endsWith('.xls')) return 'application/vnd.ms-excel';
    if (lower.endsWith('.csv')) return 'text/csv';
    if (lower.endsWith('.txt')) return 'text/plain';
    return fallback || 'application/octet-stream';
  }

  function uint8ToBase64(bytes){
    var binary = '';
    var chunk = 0x8000;
    for (var i=0;i<bytes.length;i+=chunk) {
      var part = bytes.subarray(i, Math.min(i+chunk, bytes.length));
      binary += String.fromCharCode.apply(null, part);
    }
    return btoa(binary);
  }

  function textToBase64(text){
    try { return uint8ToBase64(new TextEncoder().encode(String(text == null ? '' : text))); }
    catch(e) { return btoa(unescape(encodeURIComponent(String(text == null ? '' : text)))); }
  }

  function saveBase64(filename, mime, base64){
    var b = bridge();
    if (!b) return false;
    filename = String(filename || 'rocky-backup.json');
    mime = String(mime || guessMime(filename));
    base64 = String(base64 || '');
    try {
      // Samakan dengan AdminRocky yang sudah terbukti jalan: panggil saveFileToDownloads langsung.
      if (typeof b.saveFileToDownloads === 'function') {
        var saved = b.saveFileToDownloads(filename, mime, base64);
        if (!(saved === false || String(saved) === 'false')) return true;
      }

      // Cadangan untuk file sangat besar.
      if (typeof b.beginSaveToDownloads === 'function' && typeof b.appendSaveChunk === 'function' && typeof b.finishSaveToDownloads === 'function') {
        var session = String(b.beginSaveToDownloads(filename, mime) || '');
        if (!session) return false;
        var chunk = 64 * 1024;
        for (var i=0;i<base64.length;i+=chunk) {
          var ok = b.appendSaveChunk(session, base64.slice(i, i+chunk));
          if (ok === false || String(ok) === 'false') {
            try { if (typeof b.cancelSaveToDownloads === 'function') b.cancelSaveToDownloads(session); } catch(_e) {}
            return false;
          }
        }
        var done = b.finishSaveToDownloads(session);
        return !(done === false || String(done) === 'false');
      }
    } catch(e) {
      console.warn('Native storage save failed:', e);
    }
    return false;
  }

  function saveBlob(filename, mime, blob, fallbackClick, anchor){
    try {
      var reader = new FileReader();
      reader.onload = function(){
        var result = String(reader.result || '');
        var comma = result.indexOf(',');
        var base64 = comma >= 0 ? result.slice(comma + 1) : '';
        if (base64 && saveBase64(filename, mime || blob.type || guessMime(filename), base64)) {
          toast('✓ Backup tersimpan di Download/RockyBackup');
        } else if (fallbackClick && anchor) {
          fallbackClick.call(anchor);
        } else {
          toast('Gagal simpan backup lewat Android.', true);
        }
      };
      reader.onerror = function(){
        if (fallbackClick && anchor) fallbackClick.call(anchor);
        else toast('Gagal membaca file backup.', true);
      };
      reader.readAsDataURL(blob);
      return true;
    } catch(e) {
      return false;
    }
  }

  window.RockySaveToDownloads = function(content, filename, mimeType){
    return saveBase64(filename, mimeType || guessMime(filename), textToBase64(content));
  };

  // Override fungsi global jika halaman memakainya.
  window.downloadTextFile = function(content, filename, mimeType){
    if (saveBase64(filename, mimeType || guessMime(filename), textToBase64(content))) {
      toast('✓ Backup tersimpan di Download/RockyBackup');
      return;
    }
    toast('Gagal simpan lewat Android. Coba update APK dari project terbaru.', true);
  };

  if (nativeCreateObjectURL) {
    window.URL.createObjectURL = function(obj){
      var url = nativeCreateObjectURL(obj);
      try {
        if (obj instanceof Blob) blobStore[url] = obj;
      } catch(e) {}
      return url;
    };
  }

  if (nativeRevokeObjectURL) {
    window.URL.revokeObjectURL = function(url){
      // Jangan hapus terlalu cepat, karena fungsi download halaman biasanya revoke setelah klik.
      setTimeout(function(){ try { delete blobStore[String(url)]; } catch(e) {} }, 10000);
      return nativeRevokeObjectURL(url);
    };
  }

  var originalClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    var a = this;
    var filename = a.getAttribute('download') || 'rocky-backup.json';
    var href = String(a.href || '');
    var mime = guessMime(filename);

    if (filename && href.indexOf('blob:') === 0) {
      var storedBlob = blobStore[href];
      if (storedBlob && saveBlob(filename, storedBlob.type || mime, storedBlob, originalClick, a)) return;
      try {
        fetch(href).then(function(res){ return res.blob(); }).then(function(blob){
          if (!saveBlob(filename, blob.type || mime, blob, originalClick, a)) originalClick.call(a);
        }).catch(function(){ originalClick.call(a); });
        return;
      } catch(e) {}
    }

    if (filename && href.indexOf('data:') === 0) {
      try {
        var comma = href.indexOf(',');
        var header = href.slice(0, comma);
        var payload = href.slice(comma + 1);
        var isBase64 = /;base64/i.test(header);
        var base64 = isBase64 ? payload : textToBase64(decodeURIComponent(payload));
        if (saveBase64(filename, mime, base64)) {
          toast('✓ Backup tersimpan di Download/RockyBackup');
          return;
        }
      } catch(e) {}
    }

    return originalClick.call(a);
  };

  console.log('Rocky Android storage hook aktif v5 force save');
})();
