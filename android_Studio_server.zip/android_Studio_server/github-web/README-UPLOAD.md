Upload `index.html` ini ke GitHub Pages.
Tidak perlu upload file bridge backup Android, karena bridge sudah disuntik otomatis dari APK.
