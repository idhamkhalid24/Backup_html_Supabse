# Rocky Hijab Android - Single HTML via GitHub

Project ini dibuat ulang supaya lebih simpel:

- Android hanya membuka 1 URL GitHub Pages dari `app/src/main/res/values/strings.xml`.
- File HTML yang perlu diupload ke GitHub cukup `github-web/index.html`.
- Backup disimpan native Android ke `Download/RockyBackup`.
- Restore tetap pakai file picker Android dari `<input type="file">`.
- Script backup Android disuntik dari APK, jadi tidak perlu upload file JS bridge ke GitHub.

## Cara update HTML

1. Edit atau replace file:
   `github-web/index.html`
2. Upload file itu ke repo GitHub Pages kamu.
3. Pastikan URL di Android sesuai:
   `app/src/main/res/values/strings.xml`

Default URL:
`https://idhamkhalid24.github.io/Server_Supabse/`

Kalau repo/path berubah, ganti nilai:

```xml
<string name="github_html_url">https://username.github.io/nama-repo/</string>
```

## Cara cek backup di HP

Setelah klik backup di aplikasi, cek:

`File Manager > Internal Storage > Download > RockyBackup`

Kalau muncul toast `Backup tersimpan di Download/RockyBackup/...`, berarti native save berhasil.

## Cara ganti icon

Ganti file ini dengan nama yang sama:

`icon/data-management.png`

Lalu build ulang APK.

Background icon:

`icon/background.xml`

Ubah warna di bagian:

```xml
<solid android:color="#4F7CFF" />
```
