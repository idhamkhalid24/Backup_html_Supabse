# Rocky Hijab Android

Project Android Studio untuk menjalankan aplikasi `Pusat.refactor.html` di Android WebView.

## Isi Project

- `app/src/main/assets/Pusat.refactor.html`: file HTML cadangan yang ikut masuk APK.
- `github-web/Pusat.refactor.html`: file HTML yang siap kamu upload ke GitHub.
- `app/src/main/res/values/app_config.xml`: tempat mengatur URL GitHub, nama printer, MAC printer, dan charset printer.
- `icon/`: folder khusus untuk ubah icon aplikasi.

## Cara Pakai di Android Studio

1. Buka Android Studio.
2. Pilih `Open`.
3. Pilih folder project ini: `RockyHijabAndroid`.
4. Tunggu Gradle sync selesai.
5. Pair printer Bluetooth `RPP02N-FF57` dari pengaturan Bluetooth Android.
6. Run aplikasi ke HP.

## Ubah Icon Aplikasi

Sekarang cukup replace file:

`icon/data-management.png`

Pastikan nama file tetap sama: `data-management.png`.

Setelah diganti, build ulang dari Android Studio. Gradle otomatis menyalin file itu menjadi icon aplikasi Android.

Kalau ukuran icon terasa kurang pas, ubah:

`icon/settings.xml`

pada bagian `launcher_icon_inset`. Default sekarang `24dp` supaya logo lebih kecil.

## Cara Pakai HTML dari GitHub

1. Buat repository GitHub, misalnya `rocky-hijab-web`.
2. Upload file `github-web/Pusat.refactor.html`.
3. Buka file itu di GitHub, klik `Raw`.
4. Copy URL raw file.
5. Paste URL itu ke `app/src/main/res/values/app_config.xml` pada bagian `github_html_url`.

Kalau URL GitHub belum diisi atau gagal dibuka, aplikasi otomatis memakai HTML cadangan dari `app/src/main/assets/Pusat.refactor.html`.

## Printer Bluetooth

Project ini sudah menyiapkan permission Internet dan Bluetooth untuk Android lama maupun baru.

Printer default: `RPP02N-FF57`

HTML bisa memanggil printer native Android dengan:

```js
window.RockyPrinter.print("Teks struk yang mau dicetak");
```

Status printer:

```js
window.RockyPrinter.status();
```
