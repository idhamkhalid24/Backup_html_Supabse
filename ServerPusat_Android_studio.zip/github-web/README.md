# File HTML Untuk GitHub

Upload `Pusat.refactor.html` di folder ini ke repository GitHub kamu.

Setelah upload:

1. Buka file `Pusat.refactor.html` di GitHub.
2. Klik tombol `Raw`.
3. Copy URL dari browser.
4. Masukkan URL itu ke project Android:

   `app/src/main/res/values/app_config.xml`

   bagian `github_html_url`.

Dengan cara ini, kalau HTML di GitHub kamu update, aplikasi Android akan mengambil versi terbaru saat dibuka.
