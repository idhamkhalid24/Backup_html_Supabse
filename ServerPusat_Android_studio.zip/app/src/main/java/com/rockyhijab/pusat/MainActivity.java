package com.rockyhijab.pusat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 4207;
    private static final String FALLBACK_ASSET = "Pusat.refactor.html";
    private static final String FALLBACK_BASE_URL = "https://local.rockyhijab.app/";
    private static final long EXIT_CONFIRM_MS = 1800L;

    private WebView webView;
    private ProgressBar progressBar;
    private BluetoothPrinterManager printerManager;
    private String configuredHtmlUrl;
    private String configuredHtmlHost;
    private boolean fallbackLoaded;
    private long lastBackPressAt;
    private float swipeStartX;
    private float swipeStartY;
    private long swipeStartAt;
    private boolean swipeBackCandidate;
    private OnBackInvokedCallback backInvokedCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        configuredHtmlUrl = getString(R.string.github_html_url).trim();
        configuredHtmlHost = hostOf(configuredHtmlUrl);
        printerManager = new BluetoothPrinterManager(
                this,
                getString(R.string.printer_name),
                getString(R.string.printer_mac_address),
                getString(R.string.printer_charset)
        );

        setupUi();
        configureWebView();
        registerBackGestureHandler();
        requestBluetoothPermissionsIfNeeded();
        loadConfiguredPage();
    }

    private void setupUi() {
        setupSystemBars();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        applySystemBarPadding(root);

        webView = new WebView(this);
        setupSwipeBackGesture();
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(3)
        );
        root.addView(progressBar, progressParams);

        setContentView(root);
        root.requestApplyInsets();
    }

    private void setupSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);

        int systemUi = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            systemUi |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            systemUi |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        window.getDecorView().setSystemUiVisibility(systemUi);
    }

    private void applySystemBarPadding(final View root) {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                view.setPadding(
                        0,
                        insets.getSystemWindowInsetTop(),
                        0,
                        insets.getSystemWindowInsetBottom()
                );
                return insets;
            }
        });
    }

    private void setupSwipeBackGesture() {
        webView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        swipeStartX = event.getX();
                        swipeStartY = event.getY();
                        swipeStartAt = System.currentTimeMillis();
                        swipeBackCandidate = swipeStartX <= dp(36);
                        return false;
                    case MotionEvent.ACTION_UP:
                        if (!swipeBackCandidate) return false;

                        float dx = event.getX() - swipeStartX;
                        float dy = event.getY() - swipeStartY;
                        long elapsed = System.currentTimeMillis() - swipeStartAt;
                        swipeBackCandidate = false;

                        if (dx > dp(88) && Math.abs(dy) < dp(72) && elapsed < 650L) {
                            handleBackNavigation();
                            return true;
                        }
                        return false;
                    case MotionEvent.ACTION_CANCEL:
                        swipeBackCandidate = false;
                        return false;
                    default:
                        return false;
                }
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        webView.addJavascriptInterface(
                new PrinterBridge(this, printerManager, new PrinterBridge.TrustChecker() {
                    @Override
                    public boolean isTrusted() {
                        return isCurrentPageTrusted();
                    }
                }),
                "AndroidPrinter"
        );

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectPrinterHelper();
                injectBackNavigationHelper();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && request.isForMainFrame()) {
                    loadFallbackOnce();
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                super.onReceivedHttpError(view, request, response);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                        && request.isForMainFrame()
                        && response != null
                        && response.getStatusCode() >= 400) {
                    loadFallbackOnce();
                }
            }
        });
    }

    private void loadConfiguredPage() {
        fallbackLoaded = false;
        if (isUsableRemoteUrl(configuredHtmlUrl)) {
            webView.loadUrl(withCacheBust(configuredHtmlUrl));
            return;
        }
        loadFallbackAsset();
    }

    private void loadFallbackOnce() {
        if (!fallbackLoaded) {
            loadFallbackAsset();
        }
    }

    private void loadFallbackAsset() {
        fallbackLoaded = true;
        try {
            String html = readAsset(FALLBACK_ASSET);
            webView.loadDataWithBaseURL(FALLBACK_BASE_URL, html, "text/html", "UTF-8", null);
        } catch (Exception error) {
            Toast.makeText(this, "File HTML cadangan tidak bisa dibuka.", Toast.LENGTH_LONG).show();
        }
    }

    private String readAsset(String assetName) throws Exception {
        InputStream stream = getAssets().open(assetName);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line).append('\n');
        }
        reader.close();
        return builder.toString();
    }

    private boolean isUsableRemoteUrl(String url) {
        if (url == null || url.length() == 0) return false;
        if (url.contains("USERNAME") || url.contains("REPOSITORY") || url.contains("__")) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        String host = uri.getHost();
        return host != null && ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
    }

    private String withCacheBust(String url) {
        String separator = url.contains("?") ? "&" : "?";
        return url + separator + "app_v=" + System.currentTimeMillis();
    }

    private boolean isCurrentPageTrusted() {
        String currentUrl = webView.getUrl();
        String currentHost = hostOf(currentUrl);
        if ("local.rockyhijab.app".equalsIgnoreCase(currentHost)) return true;
        return configuredHtmlHost != null && configuredHtmlHost.equalsIgnoreCase(currentHost);
    }

    private String hostOf(String url) {
        if (url == null || url.length() == 0) return null;
        try {
            return Uri.parse(url).getHost();
        } catch (Exception ignored) {
            return null;
        }
    }

    private void injectPrinterHelper() {
        String js = "(function(){"
                + "window.RockyPrinter=window.RockyPrinter||{};"
                + "window.RockyPrinter.print=function(text){return window.AndroidPrinter.printText(String(text||''));};"
                + "window.RockyPrinter.status=function(){return window.AndroidPrinter.status();};"
                + "window.RockyPrinter.requestPermission=function(){return window.AndroidPrinter.requestBluetoothPermission();};"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void injectBackNavigationHelper() {
        String js = "(function(){"
                + "if(window.__rockyBackInstallerRunning)return;"
                + "window.__rockyBackInstallerRunning=true;"
                + "function install(){"
                + "if(!window.router||typeof window.router.navigate!=='function'){setTimeout(install,250);return;}"
                + "if(window.RockyAndroidBack&&window.RockyAndroidBack.ready)return;"
                + "var original=window.router.navigate.bind(window.router);"
                + "var stack=[];"
                + "var current='';"
                + "var silent=false;"
                + "function saved(){try{return localStorage.getItem('rocky_supabase_last_page_v1')||'';}catch(e){return '';}}"
                + "function setCurrent(page){current=page||saved()||current||'';}"
                + "function closeModal(){"
                + "var payment=document.getElementById('transaction-payment-modal');"
                + "if(payment&&payment.classList.contains('show')&&typeof window.closeTransactionPaymentModal==='function'){window.closeTransactionPaymentModal();return true;}"
                + "var trx=document.getElementById('transaction-modal');"
                + "if(trx&&trx.classList.contains('show')&&typeof window.closeTransactionModal==='function'){window.closeTransactionModal();return true;}"
                + "var modal=document.querySelector('.modal-wrap.show');"
                + "if(modal){modal.classList.remove('show');return true;}"
                + "return false;"
                + "}"
                + "window.router.navigate=function(page){"
                + "var from=current||saved();"
                + "if(!silent&&from&&from!==page&&from!=='login'&&page!=='login'){stack.push(from);if(stack.length>30)stack.shift();}"
                + "if(page==='login'){stack=[];}"
                + "setCurrent(page);"
                + "return original(page);"
                + "};"
                + "window.RockyAndroidBack={ready:true,back:function(){"
                + "if(closeModal())return true;"
                + "var page=current||saved();"
                + "var prev=stack.pop();"
                + "if(prev&&prev!==page){silent=true;try{setCurrent(prev);original(prev);}finally{setTimeout(function(){silent=false;},0);}return true;}"
                + "if(page&&page!=='home'&&page!=='login'){silent=true;try{setCurrent('home');original('home');}finally{setTimeout(function(){silent=false;},0);}return true;}"
                + "return false;"
                + "},reset:function(){stack=[];setCurrent(saved());}};"
                + "setCurrent(saved());"
                + "}"
                + "install();"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void registerBackGestureHandler() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return;

        backInvokedCallback = new OnBackInvokedCallback() {
            @Override
            public void onBackInvoked() {
                handleBackNavigation();
            }
        };
        getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                backInvokedCallback
        );
    }

    private void handleBackNavigation() {
        if (webView == null) {
            confirmExit();
            return;
        }

        if (webView.canGoBack()) {
            lastBackPressAt = 0L;
            webView.goBack();
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return !!(window.RockyAndroidBack&&window.RockyAndroidBack.back&&window.RockyAndroidBack.back());}catch(e){return false;}})();",
                value -> {
                    if (!"true".equals(value)) {
                        confirmExit();
                    } else {
                        lastBackPressAt = 0L;
                    }
                }
        );
    }

    private void confirmExit() {
        long now = System.currentTimeMillis();
        if (now - lastBackPressAt <= EXIT_CONFIRM_MS) {
            finish();
            return;
        }

        lastBackPressAt = now;
        Toast.makeText(this, "Tekan kembali sekali lagi untuk keluar.", Toast.LENGTH_SHORT).show();
    }

    void requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;

        List<String> permissions = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            }
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (!permissions.isEmpty()) {
            requestPermissions(permissions.toArray(new String[0]), REQUEST_BLUETOOTH_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_BLUETOOTH_PERMISSIONS) return;

        boolean granted = true;
        for (int result : grantResults) {
            granted = granted && result == PackageManager.PERMISSION_GRANTED;
        }

        Toast.makeText(
                this,
                granted ? "Izin Bluetooth aktif." : "Izin Bluetooth belum lengkap.",
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    public void onBackPressed() {
        handleBackNavigation();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backInvokedCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backInvokedCallback);
            backInvokedCallback = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        if (printerManager != null) {
            printerManager.shutdown();
        }
        super.onDestroy();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
