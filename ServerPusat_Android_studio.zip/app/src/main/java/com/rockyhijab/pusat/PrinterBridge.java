package com.rockyhijab.pusat;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class PrinterBridge {
    interface TrustChecker {
        boolean isTrusted();
    }

    private final Activity activity;
    private final BluetoothPrinterManager printerManager;
    private final TrustChecker trustChecker;

    PrinterBridge(Activity activity, BluetoothPrinterManager printerManager, TrustChecker trustChecker) {
        this.activity = activity;
        this.printerManager = printerManager;
        this.trustChecker = trustChecker;
    }

    @JavascriptInterface
    public void printText(String text) {
        if (!trustChecker.isTrusted()) {
            showToast("Halaman ini tidak diizinkan mengakses printer.");
            return;
        }

        if (!printerManager.hasRequiredPermission()) {
            requestBluetoothPermission();
            showToast("Izinkan Bluetooth dulu, lalu coba print lagi.");
            return;
        }

        printerManager.printText(text, new BluetoothPrinterManager.PrintCallback() {
            @Override
            public void onSuccess() {
                showToast("Berhasil dikirim ke printer.");
            }

            @Override
            public void onError(String message) {
                showToast(message);
            }
        });
    }

    @JavascriptInterface
    public String status() {
        if (!trustChecker.isTrusted()) {
            return "Halaman tidak dipercaya.";
        }
        return printerManager.describeStatus();
    }

    @JavascriptInterface
    public void requestBluetoothPermission() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (activity instanceof MainActivity) {
                    ((MainActivity) activity).requestBluetoothPermissionsIfNeeded();
                }
            }
        });
    }

    private void showToast(final String message) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
