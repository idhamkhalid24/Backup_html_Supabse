package com.rockyhijab.pusat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BluetoothPrinterManager {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    interface PrintCallback {
        void onSuccess();

        void onError(String message);
    }

    private final Context context;
    private final String printerName;
    private final String printerMacAddress;
    private final Charset charset;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    BluetoothPrinterManager(Context context, String printerName, String printerMacAddress, String charsetName) {
        this.context = context.getApplicationContext();
        this.printerName = clean(printerName);
        this.printerMacAddress = clean(printerMacAddress).toUpperCase(Locale.US);
        this.charset = resolveCharset(charsetName);
    }

    void printText(final String rawText, final PrintCallback callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                BluetoothSocket socket = null;
                try {
                    if (!hasRequiredPermission()) {
                        callback.onError("Izin Bluetooth belum aktif.");
                        return;
                    }

                    BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                    if (adapter == null) {
                        callback.onError("Perangkat ini tidak mendukung Bluetooth.");
                        return;
                    }
                    if (!adapter.isEnabled()) {
                        callback.onError("Bluetooth masih mati.");
                        return;
                    }

                    BluetoothDevice device = findPrinter(adapter);
                    if (device == null) {
                        callback.onError("Printer " + printerName + " belum dipair di pengaturan Bluetooth.");
                        return;
                    }

                    try {
                        adapter.cancelDiscovery();
                    } catch (SecurityException ignored) {
                    }

                    socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();

                    OutputStream output = socket.getOutputStream();
                    output.write(normalizePrintText(rawText).getBytes(charset));
                    output.write(new byte[]{0x0A, 0x0A, 0x0A});
                    output.flush();
                    callback.onSuccess();
                } catch (SecurityException error) {
                    callback.onError("Izin Bluetooth ditolak.");
                } catch (Exception error) {
                    callback.onError("Gagal print: " + safeMessage(error));
                } finally {
                    if (socket != null) {
                        try {
                            socket.close();
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        });
    }

    String describeStatus() {
        if (!hasRequiredPermission()) return "Izin Bluetooth belum aktif.";

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) return "Bluetooth tidak tersedia di perangkat ini.";
        if (!adapter.isEnabled()) return "Bluetooth masih mati.";

        try {
            BluetoothDevice device = findPrinter(adapter);
            return device == null
                    ? "Printer " + printerName + " belum dipair."
                    : "Printer " + safeDeviceName(device) + " siap.";
        } catch (SecurityException error) {
            return "Izin Bluetooth ditolak.";
        }
    }

    boolean hasRequiredPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    void shutdown() {
        executor.shutdownNow();
    }

    private BluetoothDevice findPrinter(BluetoothAdapter adapter) {
        Set<BluetoothDevice> devices = adapter.getBondedDevices();
        if (devices == null) return null;

        for (BluetoothDevice device : devices) {
            String address = clean(device.getAddress()).toUpperCase(Locale.US);
            String name = clean(device.getName());

            if (printerMacAddress.length() > 0 && printerMacAddress.equals(address)) {
                return device;
            }
            if (printerName.equalsIgnoreCase(name)) {
                return device;
            }
            if (name.toUpperCase(Locale.US).contains(printerName.toUpperCase(Locale.US))) {
                return device;
            }
        }
        return null;
    }

    private String safeDeviceName(BluetoothDevice device) {
        try {
            String name = clean(device.getName());
            return name.length() > 0 ? name : printerName;
        } catch (SecurityException ignored) {
            return printerName;
        }
    }

    private String normalizePrintText(String text) {
        String value = text == null ? "" : text;
        return value.replace("\r\n", "\n").replace("\r", "\n");
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim();
    }

    private static Charset resolveCharset(String charsetName) {
        try {
            String cleanName = clean(charsetName);
            return cleanName.length() == 0 ? StandardCharsets.UTF_8 : Charset.forName(cleanName);
        } catch (Exception ignored) {
            return StandardCharsets.UTF_8;
        }
    }

    private static String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.trim().length() == 0
                ? error.getClass().getSimpleName()
                : message;
    }
}
