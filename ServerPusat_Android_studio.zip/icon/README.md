# Folder Icon Aplikasi

Sekarang untuk mengganti icon aplikasi cukup ganti file ini:

`icon/data-management.png`

Caranya:

1. Siapkan PNG icon baru.
2. Rename jadi `data-management.png`.
3. Taruh/replace di folder `icon` ini dengan nama yang sama.
4. Buka Android Studio, lalu build ulang.

Yang sudah otomatis:

- PNG akan diproses ulang saat build.
- Bagian kosong/transparan yang tidak seimbang akan dipotong otomatis.
- Icon akan dibuat ke canvas 512x512.
- Logo akan dikecilkan ke ukuran aman.
- Logo akan diletakkan tepat di tengah canvas agar pas di lingkaran launcher.

Catatan:

- Disarankan tetap pakai PNG transparan agar hasil paling rapi.
- Kalau icon masih ingin dibuat lebih besar/kecil, ubah angka di `icon/settings.xml` pada `launcher_icon_inset`. Default sekarang `24dp` supaya logo lebih kecil.
- File `foreground.png` masih didukung sebagai nama lama, tapi yang utama sekarang adalah `data-management.png`.
- `background.xml` dipakai untuk warna/background icon.


Update: ukuran logo otomatis sekarang dibuat lebih kecil (`targetMax = 260`) agar lebih aman di tengah lingkaran.
