const { app, BrowserWindow, shell, dialog } = require('electron');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const initSqlJs = require('sql.js');

const APP_NAME = 'Rocky Admin Offline Desktop';
const PUBLIC_DIR = path.join(__dirname, 'public');
const PREFERRED_SYNC_PORT = Number(process.env.ROCKY_SYNC_PORT || 8765);
const MAX_SYNC_PORT = PREFERRED_SYNC_PORT + 20;
let server = null;
let SQL = null;
let db = null;
let dbFilePath = null;
let serverPort = 0;

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function getDbPath() {
  const dataDir = path.join(app.getPath('userData'), 'database');
  ensureDir(dataDir);
  return path.join(dataDir, 'rocky_backup.db');
}

function locateSqlWasm(file) {
  const candidates = [];
  if (app.isPackaged) {
    candidates.push(path.join(process.resourcesPath, file));
    candidates.push(path.join(process.resourcesPath, 'app.asar.unpacked', 'node_modules', 'sql.js', 'dist', file));
  }
  candidates.push(path.join(__dirname, 'node_modules', 'sql.js', 'dist', file));
  candidates.push(path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file));

  for (const candidate of candidates) {
    try { if (fs.existsSync(candidate)) return candidate; } catch (_) {}
  }
  return path.join(__dirname, 'node_modules', 'sql.js', 'dist', file);
}

async function openDb() {
  if (db) return db;
  dbFilePath = getDbPath();
  SQL = await initSqlJs({ locateFile: locateSqlWasm });

  let bytes = null;
  if (fs.existsSync(dbFilePath) && fs.statSync(dbFilePath).size > 0) {
    bytes = fs.readFileSync(dbFilePath);
  }

  db = bytes ? new SQL.Database(bytes) : new SQL.Database();
  db.run(`
    CREATE TABLE IF NOT EXISTS records (
      collection TEXT NOT NULL,
      id TEXT NOT NULL,
      data TEXT NOT NULL,
      created_at_ms INTEGER NOT NULL,
      updated_at_ms INTEGER NOT NULL,
      PRIMARY KEY (collection, id)
    );
  `);
  db.run('CREATE INDEX IF NOT EXISTS idx_records_collection_updated ON records(collection, updated_at_ms);');
  persistDb();
  return db;
}

function persistDb() {
  if (!db || !dbFilePath) return;
  const data = db.export();
  fs.writeFileSync(dbFilePath, Buffer.from(data));
}

function queryOne(sql, params = []) {
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params);
    if (!stmt.step()) return null;
    return stmt.getAsObject();
  } finally {
    stmt.free();
  }
}

function queryAll(sql, params = []) {
  const stmt = db.prepare(sql);
  const rows = [];
  try {
    stmt.bind(params);
    while (stmt.step()) rows.push(stmt.getAsObject());
    return rows;
  } finally {
    stmt.free();
  }
}

const ALLOWED_COLLECTION = /^[a-zA-Z0-9_.-]{1,120}$/;
function safeCollection(name) {
  const value = String(name || '').slice(0, 120);
  if (!ALLOWED_COLLECTION.test(value)) throw new Error('Nama collection tidak valid');
  return value;
}

function nowMs() { return Date.now(); }

function getRecord(collection, id) {
  const row = queryOne('SELECT data FROM records WHERE collection=? AND id=?', [collection, id]);
  if (!row) return null;
  try { return JSON.parse(row.data); } catch (_) { return null; }
}

function putRecord(collection, id, data, merge = false, persist = true) {
  let payload = data && typeof data === 'object' && !Array.isArray(data) ? data : { value: data };
  const old = merge ? getRecord(collection, id) : null;
  if (old && typeof old === 'object' && !Array.isArray(old)) {
    payload = { ...old, ...payload, id };
  } else {
    payload = { ...payload, id };
  }

  const text = JSON.stringify(payload);
  const ms = nowMs();
  const existing = queryOne('SELECT created_at_ms FROM records WHERE collection=? AND id=?', [collection, id]);
  const created = existing ? Number(existing.created_at_ms) : ms;

  db.run(
    `INSERT INTO records(collection, id, data, created_at_ms, updated_at_ms)
     VALUES(?,?,?,?,?)
     ON CONFLICT(collection, id) DO UPDATE SET data=excluded.data, updated_at_ms=excluded.updated_at_ms`,
    [collection, id, text, created, ms]
  );
  if (persist) persistDb();
  return payload;
}

function deleteRecord(collection, id) {
  db.run('DELETE FROM records WHERE collection=? AND id=?', [collection, id]);
  persistDb();
}

function sendJson(res, status, payload) {
  const body = Buffer.from(JSON.stringify(payload || { ok: true }), 'utf8');
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Rocky-Sync-Token, X-Requested-With, Authorization',
    'Access-Control-Allow-Private-Network': 'true',
    'Content-Length': body.length
  });
  res.end(body);
}

function sendError(res, status, err) {
  sendJson(res, status, { ok: false, error: String(err && err.message ? err.message : err) });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 25 * 1024 * 1024) req.destroy();
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function mimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return {
    '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon', '.woff': 'font/woff', '.woff2': 'font/woff2', '.wasm': 'application/wasm'
  }[ext] || 'application/octet-stream';
}

function serveStatic(req, res, pathname) {
  let safePath = decodeURIComponent(pathname.split('?')[0]);
  if (safePath === '/' || !safePath) safePath = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, safePath));
  if (!filePath.startsWith(PUBLIC_DIR)) return sendError(res, 403, 'Forbidden');
  fs.readFile(filePath, (err, data) => {
    if (err) return sendError(res, 404, 'File tidak ditemukan');
    res.writeHead(200, { 'Content-Type': mimeType(filePath), 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

function parseStorePath(pathname) {
  const parts = pathname.split('/').filter(Boolean).map(decodeURIComponent);
  if (parts.length < 3 || parts[0] !== 'api' || parts[1] !== 'store') throw new Error('Path store tidak valid');
  return { collection: safeCollection(parts[2]), tail: parts.slice(3) };
}


function stableHash(input) {
  const text = String(input || '');
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}

function normalizeBackupContainer(payload = {}) {
  if (payload && payload.backup && payload.backup.data) return payload.backup;
  if (payload && payload.data) return payload;
  if (payload && (payload.users || payload.transactions || payload.attendance || payload.closings || payload.manualBonuses)) {
    return { version: 'raw-data-wrapper', exportedAt: new Date().toISOString(), data: payload };
  }
  return { version: 'empty', exportedAt: new Date().toISOString(), data: {} };
}

function normalizeRecordObject(row = {}) {
  if (!row || typeof row !== 'object' || Array.isArray(row)) return {};
  return JSON.parse(JSON.stringify(row));
}

function fallbackRecordId(collection, row = {}, index = 0) {
  const clean = normalizeRecordObject(row);
  // Untuk transaksi dari Firestore, pakai ID dokumen agar tidak ketimpa field id legacy.
  const direct = collection === 'users'
    ? (clean.id || clean.username || clean.userId || clean.uid || clean.docId || clean.firestoreId || clean._docId)
    : (clean.docId || clean.firestoreId || clean._docId || clean.id || clean.username || clean.userId || clean.uid);
  if (direct) return String(direct);
  if (collection === 'users' && clean.username) return String(clean.username);
  if (collection === 'attendance') {
    const key = [clean.user || clean.username || '', clean.dateKey || clean.date || '', clean.createdAtMs || clean.createdAt || ''].join('|');
    if (key.replace(/\|/g, '')) return `attendance_${stableHash(key)}`;
  }
  if (collection === 'transactions') {
    const key = [clean.user || clean.username || '', clean.createdAtMs || clean.createdAt || '', clean.dateKey || '', clean.amount || '', clean.note || ''].join('|');
    if (key.replace(/\|/g, '')) return `transaction_${stableHash(key)}`;
  }
  if (collection === 'closings') {
    const key = [clean.type || '', clean.scope || '', clean.user || '', clean.dateKey || clean.monthKey || '', clean.closedAtMs || clean.createdAtMs || ''].join('|');
    if (key.replace(/\|/g, '')) return `closing_${stableHash(key)}`;
  }
  if (collection === 'manualBonuses') {
    const key = [clean.user || '', clean.amount || '', clean.note || clean.reason || '', clean.dateKey || '', clean.createdAtMs || ''].join('|');
    if (key.replace(/\|/g, '')) return `manual_bonus_${stableHash(key)}`;
  }
  if (collection === 'audit_logs') {
    const key = [clean.action || clean.type || '', clean.user || clean.username || '', clean.createdAtMs || clean.createdAt || '', JSON.stringify(clean.detail || clean.payload || {})].join('|');
    if (key.replace(/\|/g, '')) return `audit_${stableHash(key)}`;
  }
  return `${collection}_${Date.now()}_${index}_${stableHash(JSON.stringify(clean))}`;
}

function importRowsIntoCollection(collection, rows, stats, options = {}) {
  if (!Array.isArray(rows)) return;
  const seenThisBatch = new Set();
  const syncStamp = options.syncStamp || new Date().toISOString();
  const syncMs = Number(options.syncMs || Date.now());
  const snapshotSource = options.snapshotSource || '';
  if (options.readOnlySourceSnapshot) {
    stats.incomingIdsByCollection[collection] = stats.incomingIdsByCollection[collection] || new Set();
    stats.activeMonthsByCollection[collection] = stats.activeMonthsByCollection[collection] || new Set();
  }
  rows.forEach((sourceRow, index) => {
    const row = normalizeRecordObject(sourceRow);
    const id = fallbackRecordId(collection, row, index);
    if (!id) { stats.skipped++; return; }
    const key = `${collection}/${id}`;
    if (seenThisBatch.has(key)) { stats.skipped++; return; }
    seenThisBatch.add(key);
    const existed = !!getRecord(collection, id);
    const now = nowMs();
    const rowMonth = recordMonthKey(row);
    if (options.readOnlySourceSnapshot) {
      stats.incomingIdsByCollection[collection].add(String(id));
      if (rowMonth) stats.activeMonthsByCollection[collection].add(rowMonth);
    }
    const payload = {
      ...row,
      id,
      importedToOfflineAtMs: now,
      importedToOfflineAt: new Date(now).toISOString(),
      offlineImportSource: row.offlineImportSource || snapshotSource || 'online_firebase_sync',
      source: row.source || snapshotSource || row.source || '',
      sourceReadActive: options.readOnlySourceSnapshot ? true : (row.sourceReadActive !== false),
      sourceLastSeenAt: options.readOnlySourceSnapshot ? syncStamp : row.sourceLastSeenAt,
      sourceLastSeenAtMs: options.readOnlySourceSnapshot ? syncMs : row.sourceLastSeenAtMs,
      sourceInactiveReason: options.readOnlySourceSnapshot ? '' : row.sourceInactiveReason,
      sourceInactiveAt: options.readOnlySourceSnapshot ? '' : row.sourceInactiveAt,
      sourceInactiveAtMs: options.readOnlySourceSnapshot ? 0 : row.sourceInactiveAtMs
    };
    putRecord(collection, id, payload, true, false);
    stats.total++;
    if (existed) stats.updated++; else stats.inserted++;
    stats.byCollection[collection] = (stats.byCollection[collection] || 0) + 1;
  });
}

function rowMatchesSnapshotSource(data, snapshotSource) {
  if (!snapshotSource) return true;
  const src = String(data && (data.source || data.offlineImportSource || '') || '').toLowerCase();
  const wanted = String(snapshotSource || '').toLowerCase();
  if (!src) return false;
  if (src === wanted) return true;
  if (wanted.includes('pusat') && (src.includes('pusat') || src.includes('admin_direct') || src.includes('firebase_sync'))) return true;
  if (wanted.includes('kas') && (src.includes('kas') || src.includes('kasm') || src.includes('kaspribadi'))) return true;
  return false;
}

function markMissingSourceRowsInactive(collections, stats, options = {}) {
  if (!options.readOnlySourceSnapshot) return;
  const snapshotSource = options.snapshotSource || '';
  const syncStamp = options.syncStamp || new Date().toISOString();
  const syncMs = Number(options.syncMs || Date.now());
  stats.inactivated = stats.inactivated || 0;
  stats.inactivatedByCollection = stats.inactivatedByCollection || {};
  for (const collection of collections) {
    const activeMonths = stats.activeMonthsByCollection[collection];
    const incomingIds = stats.incomingIdsByCollection[collection];
    if (!activeMonths || !activeMonths.size || !incomingIds) continue;
    const rows = queryAll('SELECT id,data FROM records WHERE collection=?', [collection]);
    for (const dbRow of rows) {
      if (incomingIds.has(String(dbRow.id))) continue;
      let data = null;
      try { data = JSON.parse(dbRow.data); } catch (_) {}
      if (!data || data.sourceReadActive === false) continue;
      if (!rowMatchesSnapshotSource(data, snapshotSource)) continue;
      const m = recordMonthKey(data);
      if (!m || !activeMonths.has(m)) continue;
      const payload = {
        ...data,
        id: dbRow.id,
        sourceReadActive: false,
        sourceInactiveReason: 'missing_from_latest_read_only_source_snapshot',
        sourceInactiveAt: syncStamp,
        sourceInactiveAtMs: syncMs
      };
      putRecord(collection, dbRow.id, payload, false, false);
      stats.inactivated++;
      stats.inactivatedByCollection[collection] = (stats.inactivatedByCollection[collection] || 0) + 1;
    }
  }
}

function importBackupIntoSqlite(backupPayload = {}) {
  const backup = normalizeBackupContainer(backupPayload);
  const data = backup.data || {};
  const syncMs = Date.now();
  const syncStamp = new Date(syncMs).toISOString();
  const snapshotSource = String(backupPayload.snapshotSource || backup.snapshotSource || backup.source || '');
  const readOnlySourceSnapshot = Boolean(backupPayload.readOnlySourceSnapshot || backup.readOnlySourceSnapshot || backupPayload.directPusatOriginal || backupPayload.desktopBulk);
  const importOptions = { readOnlySourceSnapshot, snapshotSource, syncStamp, syncMs };
  const stats = { ok: true, total: 0, inserted: 0, updated: 0, skipped: 0, inactivated: 0, byCollection: {}, inactivatedByCollection: {}, incomingIdsByCollection: {}, activeMonthsByCollection: {}, version: backup.version || '', exportedAt: backup.exportedAt || '', db: dbFilePath };

  importRowsIntoCollection('users', Array.isArray(data.users) ? data.users : [], stats, importOptions);
  importRowsIntoCollection('attendance', Array.isArray(data.attendance) ? data.attendance : [], stats, importOptions);
  importRowsIntoCollection('transactions', Array.isArray(data.transactions) ? data.transactions : [], stats, importOptions);
  importRowsIntoCollection('closings', Array.isArray(data.closings) ? data.closings : [], stats, importOptions);
  importRowsIntoCollection('manualBonuses', Array.isArray(data.manualBonuses) ? data.manualBonuses : [], stats, importOptions);
  importRowsIntoCollection('kasm_expenses', Array.isArray(data.kasm_expenses) ? data.kasm_expenses : [], stats, importOptions);
  importRowsIntoCollection('import_logs', Array.isArray(data.importLogs || data.import_logs) ? (data.importLogs || data.import_logs) : [], stats, importOptions);
  importRowsIntoCollection('audit_logs', Array.isArray(data.auditLogs) ? data.auditLogs : [], stats, importOptions);
  importRowsIntoCollection('adminDeviceTokens', Array.isArray(data.adminDeviceTokens) ? data.adminDeviceTokens : [], stats, importOptions);

  if (data.bonusSettings && typeof data.bonusSettings === 'object') {
    importRowsIntoCollection('closings', [{ ...data.bonusSettings, id: '__bonus_settings', type: 'bonus_settings' }], stats, importOptions);
  }
  if (data.headerGuideNote && typeof data.headerGuideNote === 'object') {
    importRowsIntoCollection('closings', [{ ...data.headerGuideNote, id: '__header_icon_guide_note', type: 'header_guide_note' }], stats, importOptions);
  }
  if (data.staffDailyHomeNote && typeof data.staffDailyHomeNote === 'object') {
    importRowsIntoCollection('closings', [{ ...data.staffDailyHomeNote, id: '__staff_daily_home_note', type: 'staff_daily_home_note' }], stats, importOptions);
  }
  if (data.receiptTextSettings && typeof data.receiptTextSettings === 'object') {
    importRowsIntoCollection('closings', [{ ...data.receiptTextSettings, id: '__receipt_text_settings', type: 'receipt_text_settings' }], stats, importOptions);
  }
  if (data.rismaManualClosingConfig && typeof data.rismaManualClosingConfig === 'object') {
    importRowsIntoCollection('closings', [{ ...data.rismaManualClosingConfig, id: '__risma_manual_closing', type: 'closing_manual_config' }], stats, importOptions);
  }

  markMissingSourceRowsInactive(['attendance','transactions','closings','manualBonuses','kasm_expenses'], stats, importOptions);

  const logId = `sync_${Date.now()}_${stableHash(JSON.stringify({ exportedAt: backup.exportedAt, total: stats.total, byCollection: stats.byCollection }))}`;
  putRecord('import_logs', logId, {
    id: logId,
    type: 'online_firebase_sync',
    importedAt: new Date().toISOString(),
    importedAtMs: Date.now(),
    sourceVersion: backup.version || '',
    exportedAt: backup.exportedAt || '',
    exportedBy: backup.exportedBy || backup.sentBy || '',
    total: stats.total,
    inserted: stats.inserted,
    updated: stats.updated,
    skipped: stats.skipped,
    inactivated: stats.inactivated,
    inactivatedByCollection: stats.inactivatedByCollection,
    readOnlySourceSnapshot,
    snapshotSource,
    byCollection: stats.byCollection
  }, false, false);
  persistDb();
  delete stats.incomingIdsByCollection;
  delete stats.activeMonthsByCollection;
  return stats;
}


function asMs(v) {
  if (!v) return 0;
  if (typeof v === 'number') return v;
  if (typeof v === 'string') {
    const t = Date.parse(v);
    return Number.isFinite(t) ? t : 0;
  }
  if (v.seconds) return Number(v.seconds) * 1000;
  return 0;
}
function localDateKeyFromMs(ms) {
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(Number(ms)));
  } catch (_) {
    return new Date(Number(ms)).toISOString().slice(0, 10);
  }
}
function recordDateKey(r) {
  const direct = String(r && (r.dateKey || r.date || r.time || '') || '').slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(direct)) return direct;
  const created = String(r && r.createdAt || '').slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(created)) return created;
  const ms = Number(r && (r.createdAtMs || r.updatedAtMs || r.timestamp) || 0) || asMs(r && r.createdAt);
  return ms ? localDateKeyFromMs(ms) : '';
}
function recordMonthKey(r) {
  const m = String(r && (r.monthKey || r.offlineSnapshotMonthKey || r._offlineSnapshotMonthKey) || '').slice(0, 7);
  if (/^\d{4}-\d{2}$/.test(m)) return m;
  const d = recordDateKey(r);
  return d ? d.slice(0, 7) : '';
}
function deleteRecordsByMonth(month) {
  month = String(month || '').slice(0, 7);
  if (!/^\d{4}-\d{2}$/.test(month)) throw new Error('Bulan tidak valid');
  const collections = ['attendance', 'transactions', 'closings', 'manualBonuses', 'kasm_expenses'];
  let deleted = 0;
  for (const collection of collections) {
    const rows = queryAll('SELECT id,data FROM records WHERE collection=?', [collection]);
    for (const row of rows) {
      let data = null;
      try { data = JSON.parse(row.data); } catch (_) {}
      if (data && recordMonthKey(data) === month) {
        db.run('DELETE FROM records WHERE collection=? AND id=?', [collection, row.id]);
        deleted++;
      }
    }
  }
  persistDb();
  return deleted;
}
function deleteAllRecords() {
  const row = queryOne('SELECT COUNT(*) AS n FROM records');
  const count = Number(row ? row.n : 0);
  db.run('DELETE FROM records');
  persistDb();
  return count;
}

function getLanAddresses() {
  try {
    const os = require('os');
    const nets = os.networkInterfaces();
    const out = [];
    for (const rows of Object.values(nets)) {
      for (const net of rows || []) {
        if (net && net.family === 'IPv4' && !net.internal) out.push(`http://${net.address}:${serverPort || PREFERRED_SYNC_PORT}/api/import-backup`);
      }
    }
    return out;
  } catch (_) { return []; }
}

async function handleApi(req, res, parsedUrl) {
  try {
    await openDb();
    if (req.method === 'OPTIONS') return sendJson(res, 204, { ok: true });
    const pathname = parsedUrl.pathname.replace(/\/$/, '') || '/';

    if (pathname === '/api/health' && req.method === 'GET') {
      const row = queryOne('SELECT COUNT(*) AS n FROM records');
      return sendJson(res, 200, {
        ok: true,
        mode: 'desktop_sqlite_sqljs_no_native',
        db: dbFilePath,
        records: Number(row ? row.n : 0)
      });
    }

    if (pathname === '/api/sync-info' && req.method === 'GET') {
      return sendJson(res, 200, {
        ok: true,
        name: APP_NAME,
        mode: 'offline_desktop_sqlite_receiver',
        endpoint: `http://127.0.0.1:${serverPort || PREFERRED_SYNC_PORT}/api/import-backup`,
        lanEndpoints: getLanAddresses(),
        db: dbFilePath,
        port: serverPort || PREFERRED_SYNC_PORT
      });
    }

    if (pathname === '/api/import-backup' && req.method === 'POST') {
      const body = await readBody(req);
      const stats = importBackupIntoSqlite(body);
      return sendJson(res, 200, stats);
    }

    if (pathname === '/api/delete-month' && req.method === 'POST') {
      const body = await readBody(req);
      const deleted = deleteRecordsByMonth(body.monthKey || body.month || '');
      return sendJson(res, 200, { ok: true, deleted, monthKey: String(body.monthKey || body.month || '').slice(0, 7) });
    }

    if ((pathname === '/api/delete-all' || pathname === '/api/reset-all') && (req.method === 'POST' || req.method === 'DELETE')) {
      const deleted = deleteAllRecords();
      return sendJson(res, 200, { ok: true, deleted });
    }

    if (pathname.startsWith('/api/store/')) {
      const { collection, tail } = parseStorePath(pathname);
      if (req.method === 'GET') {
        if (tail[0] === 'count') {
          const row = queryOne('SELECT COUNT(*) AS n FROM records WHERE collection=?', [collection]);
          return sendJson(res, 200, { ok: true, count: Number(row ? row.n : 0) });
        }
        if (tail.length) {
          return sendJson(res, 200, { ok: true, record: getRecord(collection, tail[0]) });
        }
        const rows = queryAll('SELECT data FROM records WHERE collection=? ORDER BY updated_at_ms DESC', [collection]);
        const records = [];
        for (const row of rows) {
          try { records.push(JSON.parse(row.data)); } catch (_) {}
        }
        return sendJson(res, 200, { ok: true, records });
      }

      if (req.method === 'POST') {
        if (!tail.length) return sendError(res, 400, 'ID data kosong');
        const body = await readBody(req);
        const saved = putRecord(collection, tail[0], body.data || {}, Boolean(body.merge));
        return sendJson(res, 200, { ok: true, id: tail[0], record: saved });
      }

      if (req.method === 'DELETE') {
        if (!tail.length) return sendError(res, 400, 'ID data kosong');
        deleteRecord(collection, tail[0]);
        return sendJson(res, 200, { ok: true });
      }
    }

    return sendError(res, 404, 'Endpoint tidak ditemukan');
  } catch (e) {
    return sendError(res, 500, e);
  }
}

async function startServer() {
  await openDb();
  return new Promise((resolve, reject) => {
    const makeServer = () => http.createServer((req, res) => {
      const parsedUrl = new URL(req.url, 'http://127.0.0.1');
      if (parsedUrl.pathname.startsWith('/api/')) return handleApi(req, res, parsedUrl);
      return serveStatic(req, res, parsedUrl.pathname);
    });

    const tryListen = (port) => {
      server = makeServer();
      server.once('error', (err) => {
        try { server.close(); } catch (_) {}
        if (err && err.code === 'EADDRINUSE' && port < MAX_SYNC_PORT) {
          return tryListen(port + 1);
        }
        reject(err);
      });
      server.listen(port, '0.0.0.0', () => {
        serverPort = server.address().port;
        console.log(`Rocky Offline receiver aktif: http://127.0.0.1:${serverPort}/api/import-backup`);
        resolve(serverPort);
      });
    };

    tryListen(PREFERRED_SYNC_PORT);
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1080,
    minHeight: 720,
    title: APP_NAME,
    backgroundColor: '#f3f6f8',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  win.setMenuBarVisibility(false);
  win.loadURL(`http://127.0.0.1:${serverPort}/`);
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(async () => {
  try {
    await startServer();
    createWindow();
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  } catch (err) {
    dialog.showErrorBox('Rocky Admin Offline gagal dibuka', String(err && err.stack ? err.stack : err));
    app.quit();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  try { persistDb(); } catch (_) {}
  try { if (server) server.close(); } catch (_) {}
  try { if (db && typeof db.close === 'function') db.close(); } catch (_) {}
});
