CARA PAKAI FITUR SYNC ONLINE → OFFLINE PC

1. Build / install aplikasi Offline Desktop ini seperti biasa.
2. Buka aplikasi Rocky Admin Offline di PC. Aplikasi otomatis membuka receiver di port 8765.
3. Di aplikasi online Firebase, upload index.html versi sync dari paket ini.
4. Login sebagai admin di aplikasi online.
5. Buka menu Backup/Restore.
6. Klik tombol "Kirim ke Offline".

Alamat default kalau aplikasi online dibuka di PC yang sama:
http://127.0.0.1:8765/api/import-backup

Kalau aplikasi online dibuka dari HP satu WiFi:
- Buka aplikasi offline di PC
- Menu Backup/Restore offline → Info Receiver
- Salin alamat LAN, contoh http://192.168.1.10:8765/api/import-backup
- Di online klik "Atur Alamat", masukkan alamat LAN tersebut

Mode simpan:
- Data lama tidak dihapus
- Data baru ditambahkan
- Kalau ID sama, data di-update/merge sehingga import ulang tidak membuat dobel
- Database tersimpan di folder userData aplikasi sebagai database/rocky_backup.db
