Rocky Admin Offline Desktop - Update 1.1.0

Isi update:
- Tampilan desktop only, bukan layout HP.
- Menggunakan UI laporan yang sama dengan versi final: Home, Bulanan, Tahunan, Cari, Pengeluaran, Keuangan.
- Tombol Sync Semua di header menjalankan sync manual:
  1) Sync data admin Firebase direct dari collection utama.
  2) Sync pengeluaran KASM.
- Sync bersifat tambah/update, tidak menghapus data lama.
- Perhitungan omset memakai logika final berbasis docId Firestore supaya transaksi tidak ketimpa.
- Pengeluaran KASM ikut tersimpan di SQLite lokal sebagai collection kasm_expenses.
- Hapus Bulan Dipilih dan Hapus Semua Data sudah didukung backend desktop.

Cara jalan di PC:
1. Extract zip ini.
2. Jalankan: npm install
3. Jalankan aplikasi: npm start
4. Untuk membuat installer: npm run dist

Catatan:
- Internet dibutuhkan saat Sync Semua karena aplikasi membaca Firebase dan KASM/Supabase.
- Data offline tersimpan di SQLite pada folder userData Electron.
