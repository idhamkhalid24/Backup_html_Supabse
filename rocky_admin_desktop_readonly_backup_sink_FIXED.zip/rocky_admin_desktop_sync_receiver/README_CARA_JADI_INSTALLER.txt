ROCKY ADMIN OFFLINE - VERSI DESKTOP INSTALLER FIX
=================================================

Ini versi FIX dari aplikasi desktop installer.
Masalah better-sqlite3/node-gyp/Visual Studio sudah dihindari.
Database tetap SQLite, tetapi engine-nya memakai sql.js WebAssembly, jadi tidak perlu compile C++.

HASIL AKHIR SETELAH BUILD:
- Rocky-Admin-Offline-Setup-1.0.1.exe    -> installer Windows
- Rocky-Admin-Offline-Portable-1.0.1.exe -> portable EXE

CARA BUILD LANGSUNG DI PC:
1. Extract ZIP ini ke folder baru.
2. Klik 2x BUILD-FIX-TANPA-VISUAL-STUDIO.bat.
3. Tunggu selesai.
4. File installer ada di folder dist.

CARA BUILD LEWAT GITHUB ACTIONS:
1. Upload semua isi folder ini ke GitHub repository.
2. Masuk tab Actions.
3. Pilih "Build Rocky Admin Offline Windows Installer".
4. Klik "Run workflow".
5. Setelah selesai, download artifact "Rocky-Admin-Offline-Windows".

DATA TERSIMPAN DI:
C:\Users\NAMA_USER\AppData\Roaming\Rocky Admin Offline\database\rocky_backup.db

CATATAN:
- Tidak perlu Python.
- Tidak perlu Visual Studio C++ Build Tools.
- Tidak perlu start-windows.bat.
- Tidak perlu buka Chrome manual.
- Setelah install, buka dari icon Desktop / Start Menu.
- Import backup online tetap menambahkan data, bukan menimpa.
