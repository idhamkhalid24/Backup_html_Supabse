@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo  BUILD ROCKY ADMIN OFFLINE - FIX NPM ERROR
echo  Versi ini TANPA better-sqlite3/native build
echo  Jadi tidak perlu Visual Studio C++ Build Tools
echo ============================================
echo.
echo Membersihkan bekas install lama...
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /f /q package-lock.json

echo.
echo Menginstall dependency baru...
call npm install
if errorlevel 1 goto gagal

echo.
echo Membuat installer EXE...
call npm run dist
if errorlevel 1 goto gagal

echo.
echo SELESAI.
echo File installer ada di folder: dist
echo.
pause
exit /b 0

:gagal
echo.
echo GAGAL BUILD. Screenshot error ini kirim ke ChatGPT.
echo.
pause
exit /b 1
